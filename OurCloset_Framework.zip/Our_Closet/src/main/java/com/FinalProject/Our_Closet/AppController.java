package com.FinalProject.Our_Closet;

import org.apache.catalina.startup.HomesUserDatabase;
import org.omg.PortableInterceptor.USER_EXCEPTION;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.FinalProject.Our_Closet.dao.UsersRepo;
import com.FinalProject.Our_Closet.model.Users;

import ch.qos.logback.core.net.LoginAuthenticator;

@Controller
public class AppController {
	
	@Autowired
	UsersRepo usersRepo;
	
	@RequestMapping("/")
	public String home() {
		System.out.println("GET: home.jsp");
		return "home.jsp";
	}
	
	@RequestMapping("/login")
	public String login() {
		System.out.println("GET: login.jsp");
		return "login.jsp";
	}
	
	@RequestMapping("/register")
	public String register() {
		System.out.println("GET: register.jsp");
		return "register.jsp";
	}
	
	@RequestMapping("/closet_login")
	public ModelAndView loginUser(String uscEmail, String pass) {

		ModelAndView mv = new ModelAndView("newsfeed.jsp");
		Users user = usersRepo.findByuscEmail(uscEmail);
		if (user == null || !user.getPass().equals(pass)) {
//			System.out.println("entered pass: " + pass);
//			System.out.println("user pass: " + user.getPass());
			mv.setViewName("login.jsp");
			return mv;
		}
		mv.addObject("user", user);
		mv.addObject("usersRepo", usersRepo);
		mv.setViewName("newsfeed.jsp");
		System.out.println("working");
		return mv;
	}
	
	// register does not work yet
	@RequestMapping("/closet_register")
	public ModelAndView registerNewUser(Users user) {
		System.out.println("New user registered");
		System.out.println(user.getUscEmail());
		System.out.println(user.getPass());
		System.out.println(user.getfName() + " " + user.getlName());
		usersRepo.save(user);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("user", user);
		mv.setViewName("newsfeed.jsp");
		return mv;
	}

}
