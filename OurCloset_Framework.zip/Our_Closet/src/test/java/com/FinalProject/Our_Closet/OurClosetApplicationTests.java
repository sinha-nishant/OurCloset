package com.FinalProject.Our_Closet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OurClosetApplicationTests {

	@Test
	void contextLoads() {
	}

}
